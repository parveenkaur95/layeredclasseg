﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Enities;

namespace DataAccessLayer
{
    public class TOperations
    {
        List<Training> trainingList = new List<Training>();
        public bool AddTrainingData(Training obj)
        {
            bool result = false;
            trainingList.Add(obj);
            result = true;
            return result;
        }
    }
}
