﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enities
{
    public class Training
    {
        public string LOCATION { get; set; }
        public int ID { get; set; }
        public string SKILL { get; set; }
        public int  DAYS { get; set; }
        public DateTime STARTDATE { get; set; }
        public DateTime ENDDATE { get; set; }
    }
}
