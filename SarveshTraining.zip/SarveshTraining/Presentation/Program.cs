﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Enities;
using BusinessAccessLayer;

namespace Presentation
{
    class Program
    {
        static void Main(string[] args)
        {

            int choice = 0;
            Console.WriteLine("Enter Choice");
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Add();
                    break;
                case 2:
                    //Display();
                    break;
                default:
                    break;
            }
        }
            static void Add()
            {
                //CREATE ENTITY OBJECT
                Training tobj = new Training();
                Console.WriteLine("Enter Training Details");
                Console.WriteLine("Enter Location");
                tobj.LOCATION=Console.ReadLine();
                Console.WriteLine("Enter Skill");
                tobj.SKILL=Console.ReadLine();
                Console.WriteLine("Enter Duration");
                tobj.DAYS=Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Start Date");
                tobj.STARTDATE=DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Enter End Date");
                tobj.ENDDATE=DateTime.Parse(Console.ReadLine());
                
                //CREATE BUSINESS ACCESS LAYER
                TrainingBAL tBAL= new TrainingBAL();
                bool result = tBAL.AddTrainingData(tobj);
                if(result)
                    Console.WriteLine("Training Data added successfully");
                else
                    Console.WriteLine("Unsuccessful");


            }
            
    }
}
