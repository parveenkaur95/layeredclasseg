﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Enities;
using DataAccessLayer;

namespace BusinessAccessLayer
{
    public class TrainingBAL
    {
        public bool Validate(Training obj)
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();
            if (obj.LOCATION == string.Empty)
                isValid = false;
            if (!(obj.SKILL.Equals("DotNet") || obj.SKILL.Equals("Java") || obj.SKILL.Equals("Testing")))
                isValid = false;
            if (obj.DAYS < 0 || obj.DAYS > 50)
                isValid = false;
            if (obj.STARTDATE < DateTime.Now)
                isValid = false;
            if (obj.STARTDATE > obj.ENDDATE)
                isValid = false;
            return isValid;
        }
        public bool AddTrainingData(Training obj)
        {
            bool result = false;
            if(Validate(obj))
            {
                TOperations tDAL = new TOperations();
                result = tDAL.AddTrainingData(obj);
                return result;
            }

            return result;
        }
    }
}
