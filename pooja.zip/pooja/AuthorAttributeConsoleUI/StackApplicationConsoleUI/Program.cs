﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StackApplicationConsoleUI
{
    public class MyStack<T> : Stack<T> { }
    class Program
    {
        static void Main(string[] args)
        {
            MyStack<string> Cities = new MyStack<string>();
            Cities.Push("Mumbai");
            Cities.Push("Delhi");
            Cities.Push("bangalore");
            Cities.Push("Kolkata");
            Cities.Push("Chennai");
            foreach(string s in Cities)
            {
                Console.WriteLine(s);
            }
            Console.WriteLine(Cities.Contains("Mumbai"));
            Console.WriteLine(Cities.Count);
            Console.ReadKey();
        }
    }
}
