﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParamExConsoleUI
{
    delegate int mathdelegate(params int[] array);
    class Program
    {
        static void Main(string[] args)
        {
            //calling method using delegates
            MyMath obj = new MyMath();
            mathdelegate del = obj.DoSum;
            Console.WriteLine(del(4, 5, 6, 7, 8));

            //calling method by using objects
            //Console.WriteLine(obj.DoSum(4, 5, 6, 7, 8));
            Console.ReadLine();
        } 
    }
}
