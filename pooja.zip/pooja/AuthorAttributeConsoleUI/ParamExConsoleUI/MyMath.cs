﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParamExConsoleUI
{
    public class MyMath
    {
        public int DoSum(params int[] numarray)
        {
            int sum = 0;
            foreach(int i in numarray)
            {
                sum += i;
            }
            return sum;
        }
        public int DoMul(params int[] numarray)
        {
            int sum = 0;
            foreach (int i in numarray)
            {
                sum *= i;
            }
            return sum;
        }
    }
}
