﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
namespace SerializationConsoloeUI
{
    [Serializable]
    public class CStudent
    {
        int _studentId;
        string _studentName;
        int _standard;

        public int STUDENTID
        {
            get
            {
                return _studentId;
            }

            set
            {
                _studentId = value;
            }
        }

        public string STUDENTNAME
        {
            get
            {
                return _studentName;
            }

            set
            {
                _studentName = value;
            }
        }

        public int STANDARD
        {
            get
            {
                return _standard;
            }

            set
            {
                _standard = value;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<CStudent> students = new List<CStudent>()
            {
                new CStudent {STUDENTID=1,STUDENTNAME="S1",STANDARD=11},
                new CStudent {STUDENTID=2,STUDENTNAME="S2",STANDARD=12 }
            };

            SerializeData(students);

            List<CStudent> stobj1 = DeserializeData();
            foreach(CStudent item in stobj1)
            {
                Console.WriteLine("StudentId:{0}",item.STUDENTID);
                Console.WriteLine("StudentName:{0}", item.STUDENTNAME);
                Console.WriteLine("Standard:{0}", item.STANDARD);
            }
            
        }
        private static void SerializeData(List<CStudent> list)
        {
            FileStream fileStream = new FileStream("d:\\student.dat", FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fileStream, list);
            fileStream.Close();
        }
        private static List<CStudent> DeserializeData()
        {
            FileStream fileStream = new FileStream("d:\\student.dat", FileMode.Open);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
           List<CStudent> stobj1 = (List<CStudent>)binaryFormatter.Deserialize(fileStream);
            fileStream.Close();
            return stobj1;
        }
    }
}
