﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ParamExConsoleUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParamExConsoleUI.Tests
{
    [TestClass()]
    public class MyMathTests
    {
        [TestMethod()]
        public void DoSumTest()
        {
            int actual = 0;
            int expected = 30;
            MyMath obj = new MyMath();
            actual = obj.DoSum(4, 5, 6, 7, 8);
            Assert.AreEqual(actual, expected);
        }
    }
}