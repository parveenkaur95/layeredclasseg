﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeComparableConsoleUI
{
    class Emp:IComparable<Emp>
    {
    public string ENAME { get; set; }
        public int SALARY { get; set; }

        public int CompareTo(Emp other)
        {
            //throw new NotImplementedException();
            if (this.SALARY > other.SALARY)
                return 1;
            else if (this.SALARY < other.SALARY)
                return -1;
            else
                return 0;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Emp> emps = new List<Emp>()
            {
                new Emp {ENAME="E1",SALARY=15678 },
                new Emp {ENAME="E2",SALARY=15000 },
                new Emp {ENAME="E3",SALARY=15600 }
            };
            emps.Sort();
            foreach(Emp item in emps)
            {
                Console.WriteLine("name:{0} salary:{1}",item.ENAME,item.SALARY);
            }
        }
    }
}
