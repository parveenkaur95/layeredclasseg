﻿using System;
using System.Reflection;

namespace AuthorAttributeConsoleUI
{
    [AttributeUsage(AttributeTargets.Class , AllowMultiple = true)]
     class AuthorAttribute : Attribute
    {
        private string _name;
        private double _version;

        public string NAME { get { return _name; }  }
        public double VERSION { get { return _version; }  }
        public AuthorAttribute(string name, double version)
        {
            _name = name;
            _version = version;
        }
       
    }
    [AuthorAttribute("Henry Winget", 1.1)]

    [AuthorAttribute("Harry Singh", 1.2)]
    public class Student
    {

    }
    class Program
    {
        
        
        static void Main(string[] args)
        {
            
            Type type = typeof(Student);
            Console.WriteLine(type.IsAbstract);
            Console.WriteLine(type.IsClass);
            PropertyInfo[] pi = type.GetProperties();
            object[] attributes = type.GetCustomAttributes(typeof(AuthorAttribute),false);
            
                foreach (object item in attributes)
                {
                    Console.WriteLine("{0}-{1}",((AuthorAttribute)item).NAME,((AuthorAttribute)item).VERSION);
                }
            


        }
    }
}

