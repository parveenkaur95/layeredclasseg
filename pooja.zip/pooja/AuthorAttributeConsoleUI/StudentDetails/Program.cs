﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            
            List<CStudent> students = new List<CStudent>()
            {
                new CStudent {STUDENTID=1,STUDENTNAME="S1",GENDER=CStudent.Gender.Female ,STANDARD=11},
                new CStudent {STUDENTID=2,STUDENTNAME="S2",GENDER=CStudent.Gender.Male,STANDARD=12 }
            };
            Dictionary<CStudent.Gender, double> percentages = new Dictionary<CStudent.Gender, double>();
            double countmale = 0, countfemal = 0;
            double permale = 0,  perfemale = 0;
            foreach(CStudent s in students)
            {
                if (s.GENDER == CStudent.Gender.Male)
                    countmale++;
                else
                    countfemal++;
            }
            permale = countmale / students.Count * 100;
            perfemale = countfemal / students.Count * 100;
            percentages.Add(CStudent.Gender.Male, permale);
            percentages.Add(CStudent.Gender.Female, perfemale);

            foreach(KeyValuePair<CStudent.Gender, double>kv in percentages)
            {
                Console.WriteLine("gender-{0} percentage-{1}",kv.Key,kv.Value);
            }
            Console.ReadLine();
        }
    }
}
