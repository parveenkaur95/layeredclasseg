﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentDetails
{
    public class CStudent
    {
        int _studentId;
        string _studentName;
        int _standard;
        public enum Gender { Male, Female };
        public int STUDENTID
        {
            get
            {
                return _studentId;
            }

            set
            {
                _studentId = value;
            }
        }

        public string STUDENTNAME
        {
            get
            {
                return _studentName;
            }

            set
            {
                _studentName = value;
            }
        }

        public int STANDARD
        {
            get
            {
                return _standard;
            }

            set
            {
                _standard = value;
            }
        }

       public Gender GENDER { get ; set; }

    }
}
