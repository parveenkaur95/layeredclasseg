﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EntityLayer;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class CDAL
    {
        static List<CEntity> listobj = new List<CEntity>();
        public bool mAddStudent(CEntity entobj)
        {
            bool result = false;
            try
            {
                listobj.Add(entobj);
                result = true;
            }
            catch(Exception)
            {
                throw;
            }
            return result;
        }
        public List<CEntity> mDisplayStudents()
        {
            return listobj;
        }     
        public CEntity mSearchStudent(int trainingid)
        {
            CEntity entobj = null;
            foreach (CEntity item in listobj)
            {
                entobj = item;
                if (item.TRAININGID == trainingid)
                {
                    entobj = item;
                }
            }
            return entobj; 
        }
    }
}
