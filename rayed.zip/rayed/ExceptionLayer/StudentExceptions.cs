﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionLayer
{
    public class StudentExceptions : ApplicationException
    {
        public StudentExceptions() : base()
        {

        }
        public StudentExceptions(string message) : base(message)
        {
            Console.WriteLine(message);
        }
        public StudentExceptions(string message, Exception innerException) : base(message,innerException)
        {
            Console.WriteLine(message);
        }
    }
}
