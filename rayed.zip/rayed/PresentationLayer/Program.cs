﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using BusinessAccessLayer;
using ExceptionLayer;

namespace PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            int ch;
            Console.WriteLine("Enter choice 1:Add, 2: Delete, 3: Search. 4: Display, 5: Update");
            ch = int.Parse(Console.ReadLine());
            while(true)
            {
                switch(ch)
                {
                    case 1:
                        mAddStudent();
                        break;
                    case 2:
                        mDeleteStudent();
                        break;
                    case 3:
                        mSearchStudent();
                        break;
                    case 4:
                        mDisplay();
                        break;
                    case 5:
                        mUpdate();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("Enter choice 1:Add, 2: Delete, 3: Search. 4: Display, 5: Update");
                ch = int.Parse(Console.ReadLine());
            }
        }
        static void mAddStudent()
        {
            try
            {
                CEntity entobj = new CEntity();
                Console.WriteLine("Enter location of training");
                entobj.LOCATION = Console.ReadLine();
                Console.WriteLine("Enter skill");
                entobj.SKILL = Console.ReadLine();
                Console.WriteLine("Enter days");
                entobj.DAYS = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter startdate");
                entobj.STARTDATE = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Enter enddate");
                entobj.ENDDATE = DateTime.Parse(Console.ReadLine());
                CBAL balobj = new CBAL();
                bool result = balobj.addStudent(entobj);
                if (result == false)
                {
                    Console.WriteLine("Student Not Added");
                }
                else
                    Console.WriteLine("Student added");
            }
            catch (StudentExceptions ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
        static void mDeleteStudent()
        {

        }
        static void mSearchStudent()
        {
            try
            {
                Console.WriteLine("Enter trainingid to be searched");
                int trainingid = int.Parse(Console.ReadLine());
                CBAL balobj = new CBAL();
                CEntity entobj = balobj.mSearchStudent(trainingid);
                if (entobj == null)
                {
                    Console.WriteLine("Student not found");
                }
                else
                {
                    Console.WriteLine("Student found, details");
                    Console.WriteLine(entobj.TRAININGID + " " + entobj.DAYS + " " + entobj.SKILL + " " + entobj.LOCATION);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void mDisplay()
        {
            CBAL balobj = new CBAL();
            List<CEntity> studlist = balobj.mDisplayStudents();
            foreach (CEntity item in studlist)
            {
                Console.WriteLine(item.LOCATION + " " + item.TRAININGID + " " + item.SKILL + " " + item.DAYS + " " + item.STARTDATE + " " + item.ENDDATE);
            }
        }
        static void mUpdate()
        {
            
        }
    }
}
